package com.example.tareacoursera;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TextView;

public class ConfiracionActivity extends AppCompatActivity implements View.OnClickListener {
    private TextView nombre, telefono, email, descripcion;
    private TextView fecha;
    Contacto contacto;
    Button btnVolver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confiracion);
        inicializar();

        //cargarDatos();
    }
    public void inicializar(){
        nombre=findViewById(R.id.tvNombre);
        telefono=findViewById(R.id.tvTelefono);
        email=findViewById(R.id.tvCorreo);
        descripcion=findViewById(R.id.tvDescripcion);
        fecha=findViewById(R.id.tvFechaNacimiento);
        Intent intent=getIntent();
        String nombreContacto=intent.getStringExtra("nombre");
        nombre.setText(nombreContacto);
        String descripcionContacto=intent.getStringExtra("descripcion");
        descripcion.setText(descripcionContacto);
        String numeroContacto=intent.getStringExtra("telefono");
        telefono.setText(numeroContacto);
        String fechaNacimiento=intent.getStringExtra("fecha");
        fecha.setText(fechaNacimiento);
        String correoContacto=intent.getStringExtra("email");
        email.setText(correoContacto);
        /*nombre.setText(contacto.getNombre());
        telefono.setText(contacto.getTelefono());
        email.setText(contacto.getEmail());
        descripcion.setText(contacto.getDescripcion());
        fecha.setText(contacto.getFecha());*/
        btnVolver=findViewById(R.id.btnVolver);
        btnVolver.setOnClickListener(this);
    }
    public void cargarDatos(){
        nombre.setText(contacto.getNombre());
        telefono.setText(contacto.getTelefono());
        email.setText(contacto.getEmail());
        descripcion.setText(contacto.getDescripcion());
        fecha.setText(contacto.getFecha());
    }

    @Override
    public void onClick(View view) {
        //Intent intent = new Intent(ConfiracionActivity.this,MainActivity.class);
        //startActivity(intent);
        finish();

    }
}
