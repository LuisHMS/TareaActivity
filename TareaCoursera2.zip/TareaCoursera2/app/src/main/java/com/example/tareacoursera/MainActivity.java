package com.example.tareacoursera;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private EditText nombre, telefono, email, descripcion;
    private DatePicker fecha;
    private Contacto contacto;
    private Button btnSiguiente;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        nombre=findViewById(R.id.etNombre);
        telefono=findViewById(R.id.etNumero);
        email=findViewById(R.id.etCorreo);
        descripcion=findViewById(R.id.etDescripcion);
        fecha=findViewById(R.id.cvFecha);
        btnSiguiente=findViewById(R.id.btnSiguiente);
        btnSiguiente.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {


        //String name=nombre.getText().toString();
        //contacto.setDescripcion(descripcion.getText().toString());
        //contacto.setFecha(fecha.getDayOfMonth()+"/"+fecha.getMonth()+"/"+fecha.getYear());
        //contacto.setTelefono(telefono.getText().toString());
        //contacto.setEmail(email.getText().toString());
        Contacto contacto= new Contacto(nombre.getText().toString(),telefono.getText().toString(),email.getText().toString(),descripcion.getText().toString(),fecha.getDayOfMonth()+"/"+fecha.getMonth()+"/"+fecha.getYear());
        Intent intent = new Intent(MainActivity.this,ConfiracionActivity.class);
        intent.putExtra("nombre",contacto.getNombre());
        intent.putExtra("telefono",contacto.getTelefono());
        intent.putExtra("descripcion",contacto.getDescripcion());
        intent.putExtra("email",contacto.getEmail());
        intent.putExtra("fecha",contacto.getFecha());
        startActivity(intent);

    }


}
